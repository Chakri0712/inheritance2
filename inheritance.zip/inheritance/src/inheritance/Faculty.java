package inheritance;

public class Faculty {
	String name;
	float basicSalary;
	float bonusPercentage = 4;
	float carAllowancePercentage = (float) 2.5;
	
	
	public Faculty(String name,float basicSalary)
	{
		//System.out.println(this.name);
		//System.out.println(this.basicSalary);
		this.name = name;
		this.basicSalary = basicSalary;
	}
	
	public  double calculateSalary() {
		float salary = (bonusPercentage*basicSalary)/100+(carAllowancePercentage*basicSalary)/100+basicSalary;
		return salary;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name){
		this.name = name;
	}
	public float getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(float basicSalary){
		this.basicSalary = basicSalary;
	}
	public float getBonusPercentage() {
		return bonusPercentage;
	}
	public void setBonusPercentage(float bonusPercentage) {
		this.bonusPercentage = bonusPercentage;
	}
	public float getCarAllowancePercentage() {
		return carAllowancePercentage;
	}
	public void setCarAllowancePercentage(float carAllowancePercentage) {
		this.carAllowancePercentage = carAllowancePercentage;
	}
	
	
	
	
	
	
	
	
}


