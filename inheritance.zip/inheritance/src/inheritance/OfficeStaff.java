package inheritance;

public class OfficeStaff extends Faculty {
	
	String designation;
	public OfficeStaff(String name, float basicSalary,String designation) {
		super(name, basicSalary);
		//System.out.println(this.designation);
		this.designation = designation;
		// TODO Auto-generated constructor stub
	}
	double Salary = calculateSalary();
	public double calculatesalary() {
		double salary;
		if(designation.equals("Accountant")) {
			salary = Salary+10000;
		}
		else if(designation.equals("Clerk")) {
			salary = Salary+7000;
		}
		else if(designation.equals("Peon")) {
			salary = Salary+4500;
		}
		else salary = super.basicSalary+0;
		return salary;
	}
	
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}


	
}
