package inheritance;

public class Teacher extends Faculty{
	
	String qualification;
	public Teacher(String name, float basicSalary,String qualification) {
		super(name, basicSalary);
		this.qualification = qualification;
		// TODO Auto-generated constructor stub
	}

	double Salary = calculateSalary();
	public double calculatesalary() {
		double salary;
		if(qualification.equals("Doctoral")) {
			salary = Salary+20000;
		}
		else if(qualification.equals("Masters")) {
			salary = Salary+18000;
		}
		else if(qualification.equals("Bachelors")) {
			salary = Salary+15500;
		}
		else salary = super.basicSalary+0;
		return salary;
	}
	
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

}
