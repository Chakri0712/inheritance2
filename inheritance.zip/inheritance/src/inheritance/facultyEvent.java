package inheritance;

public class facultyEvent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Teacher teacher = new Teacher("Chakri",20000,"Doctoral");
		double totalSalary = teacher.calculatesalary();
		
		System.out.println("Teacher Details");
		System.out.println("****************");
		System.out.println("Name: "+teacher.getName());
		System.out.println("Qualification: "+teacher.getQualification());
		System.out.println("Total Salary: "+ totalSalary);
	
		System.out.println();
	
		OfficeStaff officestaff = new OfficeStaff("Pravinya", 5000, "Accountant");
		double totalsalary = officestaff.calculatesalary();
		
		System.out.println("Office Staff Details");
		System.out.println("********************");
		System.out.println("Name: "+officestaff.getName());
		System.out.println("Designation: "+officestaff.getDesignation());
		System.out.println("Total Salary: "+ totalsalary);
	
	
	}

}
